#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <fcntl.h>
#include <io.h>
#include <iostream>
#include <fstream>
#include <numeric>
#include <set>
using namespace std;

wchar_t phrase[20000][100];
int a[20000];
wchar_t spec[] = { L' ', L'\n', L'\t' };

set <wchar_t> wl;
set <wchar_t> cdict;

bool isChar(wchar_t c) {
    return (wl.find(c) == wl.end());
}

int main()
{
    _setmode(_fileno(stdout), _O_U16TEXT);
    _setmode(_fileno(stdin),  _O_U16TEXT);

    wchar_t line[100];

    FILE * charwl = NULL;
    FILE * newinp = NULL;
    FILE * out = NULL;
    FILE * chinese = NULL;

    charwl = _wfopen(L"char_wl.db", L"r,ccs=UTF-16LE");
    if (!charwl)
    {
        wprintf(L"ERROR: Cannot open file\n");
        return EXIT_FAILURE;
    }

    newinp = _wfopen(L"new_input.txt", L"r,ccs=UTF-16LE");
    if (!newinp) {
        wprintf(L"ERROR: Cannot open file\n");
        return EXIT_FAILURE;
    }

    out = _wfopen(L"OUTPUT.txt", L"w,ccs=UTF-16LE");
    if (!newinp) {
        wprintf(L"ERROR: Cannot open file\n");
        return EXIT_FAILURE;
    }

    chinese = _wfopen(L"chinese.db", L"r,ccs=UTF-16LE");
    if (!chinese) {
        wprintf(L"ERROR: Cannot open file\n");
        return EXIT_FAILURE;
    }

    wchar_t tmp;
    while (fwscanf(charwl, L"%c", &tmp)) {
        if (tmp != L'\n') wl.insert(tmp);
    }
    for (int i = 0; i < 3; i++) wl.insert(spec[i]);

    for (auto _: wl) fwprintf(out, L"%c", _);

    while (fwscanf(chinese, L"%c", &tmp)) {
        if (tmp != L'\n') cdict.insert(tmp);
    }
    fclose(chinese);

    while (fwscanf(newinp, L"%c", &tmp)) {
        if (isChar(tmp)) cdict.insert(tmp);
    }

    chinese = _wfopen(L"chinese.db", L"w,ccs=UTF-16LE");
    if (!chinese) {
        wprintf(L"ERROR: Cannot open file\n");
        return EXIT_FAILURE;
    }

    for (auto kanji: cdict) {
        if (!isChar(kanji)) continue;
        fwprintf(chinese, L"%c\n", kanji);
        fwprintf(out, L"%d ", (int) kanji);
    }

    cerr << cdict.size();

    return EXIT_SUCCESS;
}


